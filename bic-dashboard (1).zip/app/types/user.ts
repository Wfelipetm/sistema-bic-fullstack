export interface UserProfile {
  id: string
  name: string
  email: string
  role: string
  avatar?: string
  crea?: string
}
