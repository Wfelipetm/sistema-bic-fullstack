import Configuracoes from "@/components/configuracoes/configuracoes"

export default function ConfiguracoesPage() {
  return <Configuracoes />
}
