import Relatorios from "@/components/relatorios/relatorios"

export default function RelatoriosPage() {
  return <Relatorios />
}
