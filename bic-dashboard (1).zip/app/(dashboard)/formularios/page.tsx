import FormularioTecnico from "@/components/formularios/formulario-tecnico"

export default function FormulariosPage() {
  return <FormularioTecnico />
}
